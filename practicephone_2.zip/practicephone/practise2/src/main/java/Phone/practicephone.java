package Phone;

import java.util.Scanner;

public class practicephone {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Практическая работа №2, Вариант 2, РИБО-01-21, Шалунова А.С.");
        System.out.println("Введите модель телефона: ");
        String model = scan.next();
        System.out.println("Введите год релиза: ");
        int realease = scan.nextInt();
        System.out.println("Введите ёмкость батареи: ");
        String capacity = scan.next();
        System.out.println("Выберите цифру: 1 - Кнопочный телефон, 2 - Сенсорный телефон");
        int a = scan.nextInt();
        if (a==1) {
            System.out.println("Введите тип корпуса: ");
            String type = scan.next();
            System.out.println("Введите тип клавиатуры: ");
            String keyboard = scan.next();
            ButtonPhone phone1 = new ButtonPhone(model, realease, capacity, type, keyboard);
            System.out.println(phone1.toString());
        } else {
            System.out.println("Введите тип TouchId: ");
            String touchId = scan.next();
            System.out.println("Введите кол-во камер: ");
            int cameras = Integer.parseInt(scan.next());
            System.out.println("Введите разрешение: ");
            String resolution = scan.next();
            Smartphone phone2 = new Smartphone(model, realease, capacity, touchId, cameras, resolution);
            System.out.println(phone2.toString());

        }

    }
}
