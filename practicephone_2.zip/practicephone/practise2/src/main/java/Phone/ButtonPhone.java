package Phone;

public class ButtonPhone extends Phone {
    private String type;
    private String keyboard;
    public ButtonPhone(String type, int keyboard, String model, String realease, String capacity) {
        super(model, Integer.parseInt(realease), capacity);
        this.type = type;
        this.keyboard = String.valueOf(keyboard);
    }
    public String getType() {
        return type;
    }
    public String getKeyboard() {
        return keyboard;
    }

    @Override
    public String toString() {
        return "Ваше устройство --->" + " Model: " + getModel() + ", Realease: " + getRealease() + ", Capacity: " + getCapacity() + ", Тип корпуса: " + getType() + ", Keyboard: " + getKeyboard() +  " <---";
    }
}
