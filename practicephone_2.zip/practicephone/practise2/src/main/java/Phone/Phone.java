package Phone;

public class Phone {
    private String model;
    private int realease;
    private String capacity;

    public Phone(String model, int realease, String capacity) {
        this.model = model;
        this.realease = realease;
        this.capacity = capacity;
    }
    public String getModel() {
        return model;

    }
    public int getRealease() {
        return realease;
    }
    public String getCapacity() {
        return capacity;
    }

}
